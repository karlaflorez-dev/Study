"""
Data Study Hub — Daily Email Script (v3)
- Solo corre días laborales colombianos
- Genera 5 conceptos nuevos + repasos (spaced repetition)
- Guarda conceptos en data/concepts.json para que la web los muestre
- Guarda historial en data/history.json para no repetir
"""

import os, json, base64, requests
from datetime import datetime, timezone, timedelta, date

ANTHROPIC_API_KEY = os.environ["ANTHROPIC_API_KEY"]
RESEND_API_KEY    = os.environ["RESEND_API_KEY"]
EMAIL_TO          = os.environ["EMAIL_TO"]
EMAIL_FROM        = os.environ.get("EMAIL_FROM", "onboarding@resend.dev")
SITE_URL          = os.environ.get("SITE_URL", "https://tu-usuario.github.io/data-study-hub")
GITHUB_TOKEN      = os.environ.get("GITHUB_TOKEN", "")
GITHUB_REPO       = os.environ.get("GITHUB_REPOSITORY", "")

BOGOTA_TZ = timezone(timedelta(hours=-5))
today     = datetime.now(BOGOTA_TZ).date()
today_str = today.isoformat()

FESTIVOS_CO = {
    "2025-01-01","2025-01-06","2025-03-24","2025-04-17","2025-04-18",
    "2025-05-01","2025-06-02","2025-06-23","2025-06-30","2025-07-20",
    "2025-08-07","2025-08-18","2025-10-13","2025-11-03","2025-11-17",
    "2025-12-08","2025-12-25",
    "2026-01-01","2026-01-12","2026-03-23","2026-04-02","2026-04-03",
    "2026-05-01","2026-05-18","2026-06-08","2026-06-15","2026-07-20",
    "2026-08-07","2026-08-17","2026-10-12","2026-11-02","2026-11-16",
    "2026-12-08","2026-12-25",
}

def is_business_day(d):
    if d.weekday() >= 5: return False
    if d.isoformat() in FESTIVOS_CO: return False
    return True

if not is_business_day(today):
    print(f"Hoy {today_str} es fin de semana o festivo colombiano. Sin correo.")
    exit(0)

print(f"Día laboral: {today_str}")
DATE_DISPLAY = today.strftime("%A %d de %B de %Y")
day_names_es = ["lunes","martes","miércoles","jueves","viernes","sábado","domingo"]
day_name = day_names_es[today.weekday()]

# ── GitHub file helpers ────────────────────────────────────────────────────
def gh_headers():
    return {
        "Authorization": f"Bearer {GITHUB_TOKEN}",
        "Accept": "application/vnd.github.v3+json"
    }

def read_json_file(path):
    """Lee un JSON del repo. Retorna (data, sha) o ({}, None) si no existe."""
    if not GITHUB_TOKEN or not GITHUB_REPO:
        return {}, None
    r = requests.get(
        f"https://api.github.com/repos/{GITHUB_REPO}/contents/{path}",
        headers=gh_headers(), timeout=10
    )
    if r.status_code == 404:
        return {}, None
    r.raise_for_status()
    content = base64.b64decode(r.json()["content"]).decode("utf-8")
    return json.loads(content), r.json()["sha"]

def write_json_file(path, data, sha, commit_msg):
    """Escribe o actualiza un JSON en el repo."""
    if not GITHUB_TOKEN or not GITHUB_REPO:
        return
    payload = {
        "message": commit_msg,
        "content": base64.b64encode(
            json.dumps(data, ensure_ascii=False, indent=2).encode()
        ).decode(),
        "committer": {"name": "Data Study Bot", "email": "bot@datastudy.dev"}
    }
    if sha:
        payload["sha"] = sha
    requests.put(
        f"https://api.github.com/repos/{GITHUB_REPO}/contents/{path}",
        headers=gh_headers(), json=payload, timeout=20
    ).raise_for_status()

# ── Cargar archivos existentes ─────────────────────────────────────────────
history,  history_sha  = read_json_file("data/history.json")
concepts, concepts_sha = read_json_file("data/concepts.json")

if not history:  history  = {"enviados": []}
if not concepts: concepts = {"generados": []}

all_sent      = [c for d in history["enviados"] for c in d["conceptos"]]
sent_recently = [c for d in history["enviados"][-5:] for c in d["conceptos"]]
days_elapsed  = len(history["enviados"])

# Spaced repetition: repasar conceptos de hace 7+ días laborales
repaso_pool = []
for i, entry in enumerate(history["enviados"]):
    if days_elapsed - i >= 7:
        repaso_pool.extend(entry["conceptos"])
repaso_titulos = repaso_pool[:2]

MODULES = [
    "Arquitectura de datos: Data Lake, Data Warehouse, Lakehouse, Data Mesh, arquitectura medallion (Bronze/Silver/Gold)",
    "Pipelines de datos: ETL, ELT, dbt, Fivetran, Airbyte, batch vs streaming, Apache Airflow, Prefect, Dagster",
    "DevOps y MLOps: CI/CD, Docker, Kubernetes, MLflow, feature stores, model registry, monitoreo de modelos",
    "Big Data: Apache Spark, Hadoop, Flink, procesamiento distribuido, las 5 V, particionamiento, optimización",
    "Cloud para datos: AWS vs GCP vs Azure, servicios de datos en cada nube, FinOps, multi-cloud, serverless",
    "Gobernanza del dato: Data Catalog, Data Lineage, Data Steward, clasificación, privacidad, RBAC, Data Contracts",
    "IA y LLMs: tipos de ML, arquitecturas transformer, fine-tuning, RAG, embeddings, vector databases, LLMOps",
    "Calidad y observabilidad: Great Expectations, Monte Carlo, Soda, dbt tests, SLAs de datos, data contracts",
    "Ciclo de vida del dato: generación, almacenamiento, retención, destrucción, soberanía, linaje end-to-end",
    "Legislación y ética: EU AI Act (niveles de riesgo), CONPES 3975/4023, Ley 1581, GDPR, AI Ethics frameworks",
    "Streaming y tiempo real: Apache Kafka, Kinesis, Pub/Sub, event-driven, CDC, Change Data Capture, latencia",
    "Modelado de datos: modelos dimensionales, Data Vault, OBT, esquema estrella vs copo de nieve, normalización",
]
module_hoy = MODULES[days_elapsed % len(MODULES)]

# ── Llamar a Claude ────────────────────────────────────────────────────────
print(f"Módulo: {module_hoy}")
print(f"Repasos: {repaso_titulos}")

user_prompt = f"""Hoy es {today_str}, día laboral {days_elapsed + 1} del programa de estudio.
MÓDULO: {module_hoy}
NO repitas estos conceptos recientes: {json.dumps(sent_recently[:30], ensure_ascii=False)}
CONCEPTOS A REPASAR (spaced repetition, incluir si la lista no está vacía): {json.dumps(repaso_titulos, ensure_ascii=False)}

Genera exactamente 5 conceptos NUEVOS del módulo + {len(repaso_titulos)} repaso(s) si aplica.

Responde SOLO con JSON válido sin markdown ni backticks:
{{
  "modulo": "nombre del módulo",
  "conceptos_nuevos": [
    {{
      "titulo": "nombre preciso",
      "tag": "arq|pipe|dev|big|cloud|gov|ia|cal|dato|leg|stream|model",
      "tagLabel": "Arquitectura|Pipelines|DevOps/MLOps|Big Data|Cloud|Gobernanza|IA/LLMs|Calidad|Ciclo del Dato|Legislación|Streaming|Modelado",
      "nivel": "Básico|Intermedio|Avanzado",
      "analogia": "analogía cotidiana memorable en 1 oración",
      "def": "definición técnica de 2-3 oraciones con herramientas reales",
      "example": "ejemplo con empresa colombiana o latinoamericana real, 2-3 oraciones con datos concretos",
      "vs": [{{"title": "Concepto A", "body": "diferencia clave"}}, {{"title": "Concepto B", "body": "diferencia clave"}}],
      "who": [{{"role": "Data Engineer", "sen": "Mid/Sr", "chip": "sen-mid"}}],
      "reg": ["EU AI Act: relación en 1 línea", "CONPES: relación en 1 línea"],
      "quiz": {{
        "q": "pregunta de comprensión profunda",
        "opts": ["A: opción", "B: opción", "C: opción", "D: opción"],
        "correct": 0,
        "exp": "explicación de 2-3 oraciones"
      }}
    }}
  ],
  "repaso": [
    {{
      "titulo": "título exacto del concepto a repasar",
      "recordatorio": "2-3 oraciones desde un ángulo nuevo o ejemplo diferente",
      "pregunta_flash": "pregunta de repaso rápido",
      "respuesta_flash": "respuesta directa en 1 línea"
    }}
  ],
  "quiz_del_dia": {{
    "concepto": "nombre del concepto",
    "pregunta": "pregunta de comprensión profunda",
    "opciones": ["A: texto", "B: texto", "C: texto", "D: texto"],
    "correcta": "A",
    "explicacion": "explicación de 2-3 oraciones"
  }}
}}"""

r = requests.post(
    "https://api.anthropic.com/v1/messages",
    headers={"x-api-key": ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json"},
    json={"model": "claude-sonnet-4-20250514", "max_tokens": 4000,
          "system": "Eres experto en datos, ingeniería de datos, Big Data, cloud, DevOps/MLOps, IA/LLMs y legislación (EU AI Act, CONPES Colombia). Genera fichas de estudio técnicas para perfil intermedio en Colombia. Responde SOLO con JSON válido sin markdown.",
          "messages": [{"role": "user", "content": user_prompt}]},
    timeout=90,
)
r.raise_for_status()
data = json.loads(r.json()["content"][0]["text"].strip())
print(f"Generados: {len(data['conceptos_nuevos'])} conceptos + {len(data.get('repaso', []))} repasos")

# ── Actualizar concepts.json (para la web) ─────────────────────────────────
# Añadir fecha y id único a cada concepto nuevo
nuevos_con_meta = []
for i, c in enumerate(data["conceptos_nuevos"]):
    c["id"]    = f"gen_{today_str}_{i}"
    c["fecha"] = today_str
    c["modulo_dia"] = data["modulo"]
    nuevos_con_meta.append(c)

concepts["generados"].extend(nuevos_con_meta)
# Conservar últimos 500 conceptos generados para no hacer el JSON enorme
concepts["generados"] = concepts["generados"][-500:]

write_json_file(
    "data/concepts.json",
    concepts,
    concepts_sha,
    f"feat: add {len(nuevos_con_meta)} concepts from {today_str}"
)
print(f"✓ concepts.json actualizado ({len(concepts['generados'])} conceptos acumulados)")

# ── Actualizar history.json ────────────────────────────────────────────────
history["enviados"].append({
    "fecha": today_str,
    "conceptos": [c["titulo"] for c in data["conceptos_nuevos"]]
})
history["enviados"] = history["enviados"][-90:]
write_json_file("data/history.json", history, history_sha, f"chore: update history {today_str}")
print("✓ history.json actualizado")

# ── Construir HTML del correo ──────────────────────────────────────────────
NIVEL_COLORS = {
    "Básico":     ("#d1fae5","#065f46"),
    "Intermedio": ("#dbeafe","#1e40af"),
    "Avanzado":   ("#ede9fe","#4c1d95"),
}

def concept_block(c, idx):
    nbg, nfg = NIVEL_COLORS.get(c.get("nivel","Intermedio"), ("#f3f4f6","#374151"))
    who_h = "".join(
        f'<span style="display:inline-block;background:#e0f2fe;color:#0369a1;border-radius:20px;padding:2px 9px;font-size:11px;margin:2px;font-family:monospace">{w["role"]} · {w["sen"]}</span>'
        for w in c.get("who", [])
    )
    reg_items = c.get("reg", [])
    reg_h = ""
    if reg_items:
        eu = next((x for x in reg_items if x.startswith("EU")), "—")
        co = next((x for x in reg_items if not x.startswith("EU")), "—")
        reg_h = f"""<table width="100%" cellpadding="0" cellspacing="4" style="margin:10px 0 0">
          <tr>
            <td width="49%" style="background:#eff6ff;border-radius:6px;padding:9px 11px;vertical-align:top">
              <p style="margin:0 0 2px;font-size:10px;font-weight:600;color:#1e40af;font-family:monospace">🇪🇺 EU AI ACT</p>
              <p style="margin:0;font-size:11px;color:#1e3a5f;line-height:1.5">{eu}</p>
            </td><td width="2%"></td>
            <td width="49%" style="background:#fffbeb;border-radius:6px;padding:9px 11px;vertical-align:top">
              <p style="margin:0 0 2px;font-size:10px;font-weight:600;color:#92400e;font-family:monospace">🇨🇴 CONPES</p>
              <p style="margin:0;font-size:11px;color:#78350f;line-height:1.5">{co}</p>
            </td>
          </tr></table>"""
    vs = c.get("vs", [])
    vs_h = ""
    if len(vs) >= 2:
        vs_h = f"""<table width="100%" cellpadding="0" cellspacing="4" style="margin:8px 0">
          <tr>
            <td width="49%" style="background:#fafafa;border:1px solid #e5e7eb;border-radius:6px;padding:9px 11px;font-size:12px;color:#374151;vertical-align:top"><strong>{vs[0]['title']}</strong><br>{vs[0]['body']}</td>
            <td width="2%"></td>
            <td width="49%" style="background:#fafafa;border:1px solid #e5e7eb;border-radius:6px;padding:9px 11px;font-size:12px;color:#374151;vertical-align:top"><strong>{vs[1]['title']}</strong><br>{vs[1]['body']}</td>
          </tr></table>"""
    return f"""<tr><td style="padding:0 0 14px">
      <table width="100%" cellpadding="0" cellspacing="0" style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden">
        <tr><td style="background:#0f172a;padding:13px 18px">
          <table width="100%" cellpadding="0" cellspacing="0"><tr>
            <td><span style="font-size:11px;color:#64748b;font-family:monospace">#{idx}</span>
            <span style="font-size:15px;font-weight:700;color:#f8fafc;margin-left:8px">{c['titulo']}</span></td>
            <td align="right"><span style="background:{nbg};color:{nfg};border-radius:4px;padding:2px 8px;font-size:11px">{c.get('nivel','')}</span></td>
          </tr></table>
        </td></tr>
        <tr><td style="background:#1e293b;padding:9px 18px;border-left:3px solid #00d4aa">
          <p style="margin:0;font-size:12px;color:#94a3b8;font-style:italic;line-height:1.5">💡 {c.get('analogia','')}</p>
        </td></tr>
        <tr><td style="padding:14px 18px">
          <p style="margin:0 0 5px;font-size:10px;font-weight:600;color:#6b7280;text-transform:uppercase;letter-spacing:.06em">Definición</p>
          <p style="margin:0 0 12px;font-size:13px;color:#111827;line-height:1.7">{c.get('def','')}</p>
          <p style="margin:0 0 5px;font-size:10px;font-weight:600;color:#6b7280;text-transform:uppercase;letter-spacing:.06em">Ejemplo colombiano</p>
          <div style="background:#f0fdf4;border-left:3px solid #22c55e;border-radius:0 6px 6px 0;padding:10px 13px;margin-bottom:12px">
            <p style="margin:0;font-size:13px;color:#166534;line-height:1.65">{c.get('example','')}</p>
          </div>
          <p style="margin:0 0 4px;font-size:10px;font-weight:600;color:#6b7280;text-transform:uppercase;letter-spacing:.06em">Comparativa</p>
          {vs_h}
          <p style="margin:8px 0 4px;font-size:10px;font-weight:600;color:#6b7280;text-transform:uppercase;letter-spacing:.06em">¿Quién trabaja con esto?</p>
          <p style="margin:0 0 8px">{who_h}</p>
          {reg_h}
        </td></tr>
      </table>
    </td></tr>"""

def repaso_block(rep):
    return f"""<tr><td style="padding:0 0 10px">
      <table width="100%" cellpadding="0" cellspacing="0" style="background:#fffbeb;border:1px solid #fde68a;border-radius:10px">
        <tr><td style="padding:14px 18px">
          <p style="margin:0 0 2px;font-size:10px;font-weight:600;color:#92400e;font-family:monospace;text-transform:uppercase">🔁 Repaso — {rep['titulo']}</p>
          <p style="margin:6px 0 10px;font-size:13px;color:#78350f;line-height:1.65">{rep['recordatorio']}</p>
          <div style="background:#fef3c7;border-radius:6px;padding:10px 13px">
            <p style="margin:0 0 4px;font-size:12px;font-weight:600;color:#92400e">❓ {rep['pregunta_flash']}</p>
            <p style="margin:0;font-size:12px;color:#78350f">✓ {rep['respuesta_flash']}</p>
          </div>
        </td></tr>
      </table>
    </td></tr>"""

conceptos_html = "".join(concept_block(c, i+1) for i, c in enumerate(data["conceptos_nuevos"]))
repasos_html = ""
if data.get("repaso"):
    repasos_html = """<tr><td style="padding:8px 0 4px">
      <p style="margin:0;font-size:13px;font-weight:700;color:#92400e;border-bottom:1px solid #fde68a;padding-bottom:8px">🔁 Repaso espaciado</p>
    </td></tr>""" + "".join(repaso_block(r) for r in data["repaso"])

quiz = data["quiz_del_dia"]
opts_html = "".join(
    f'<li style="margin:5px 0;padding:8px 12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;color:#374151">{o}</li>'
    for o in quiz["opciones"]
)

email_html = f"""<!DOCTYPE html><html lang="es">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:'Segoe UI',Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;padding:24px 12px">
<tr><td align="center"><table width="620" cellpadding="0" cellspacing="0" style="max-width:620px;width:100%">

  <tr><td style="background:#0f172a;border-radius:14px 14px 0 0;padding:22px 26px 18px">
    <p style="margin:0 0 4px;font-size:11px;color:#475569;font-family:monospace;text-transform:uppercase;letter-spacing:.1em">{day_name} {today_str}</p>
    <h1 style="margin:0 0 6px;font-size:21px;font-weight:700;color:#f8fafc;line-height:1.2">
      📊 5 conceptos nuevos{' + ' + str(len(data.get('repaso',[]))) + ' repaso(s)' if data.get('repaso') else ''}
    </h1>
    <p style="margin:0;font-size:13px;color:#64748b">
      <span style="background:#1e293b;border-radius:4px;padding:2px 9px;font-family:monospace">{data['modulo']}</span>
      &nbsp;·&nbsp;<span style="color:#94a3b8">Día {days_elapsed + 1}</span>
    </p>
  </td></tr>

  <tr><td style="background:#f8fafc;padding:18px 18px 4px">
    <table width="100%" cellpadding="0" cellspacing="0">
      {conceptos_html}
      {repasos_html}
      <tr><td style="padding:6px 0 14px">
        <table width="100%" cellpadding="0" cellspacing="0" style="background:#fff;border:1px solid #e2e8f0;border-radius:12px">
          <tr><td style="background:#1e293b;padding:13px 18px;border-radius:11px 11px 0 0">
            <p style="margin:0;font-size:13px;font-weight:700;color:#f8fafc">🧠 Quiz del día — {quiz['concepto']}</p>
          </td></tr>
          <tr><td style="padding:14px 18px">
            <p style="margin:0 0 10px;font-size:14px;font-weight:500;color:#111827;line-height:1.5">{quiz['pregunta']}</p>
            <ul style="list-style:none;padding:0;margin:0 0 12px">{opts_html}</ul>
            <div style="background:#ecfdf5;border:1px solid #a7f3d0;border-radius:8px;padding:12px 14px">
              <p style="margin:0 0 3px;font-size:12px;font-weight:700;color:#065f46">✓ Respuesta: {quiz['correcta']}</p>
              <p style="margin:0;font-size:13px;color:#166534;line-height:1.6">{quiz['explicacion']}</p>
            </div>
          </td></tr>
        </table>
      </td></tr>
    </table>
  </td></tr>

  <tr><td style="background:#0f172a;padding:18px 26px;text-align:center;border-radius:0 0 14px 14px">
    <a href="{SITE_URL}" style="display:inline-block;background:#00d4aa;color:#0f172a;font-weight:700;font-size:14px;padding:11px 26px;border-radius:8px;text-decoration:none">
      Ver todos los conceptos en la web →
    </a>
    <p style="margin:12px 0 0;font-size:11px;color:#475569">Solo días laborales colombianos · <a href="{SITE_URL}" style="color:#64748b">Data Study Hub</a></p>
  </td></tr>

</table></td></tr>
</table>
</body></html>"""

# ── Enviar correo ──────────────────────────────────────────────────────────
res = requests.post(
    "https://api.resend.com/emails",
    headers={"Authorization": f"Bearer {RESEND_API_KEY}", "Content-Type": "application/json"},
    json={
        "from":    EMAIL_FROM,
        "to":      [EMAIL_TO],
        "subject": f"📊 [{day_name}] 5 conceptos: {data['modulo']} — Data Study Hub",
        "html":    email_html,
    },
    timeout=30,
)
res.raise_for_status()
print(f"✓ Correo enviado. ID: {res.json().get('id')}")
print(f"✓ Conceptos guardados en concepts.json para la web")
